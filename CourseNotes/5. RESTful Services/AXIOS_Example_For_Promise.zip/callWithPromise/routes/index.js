var express = require('express');
var axios = require('axios');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Making a call to a rest service with Promise', data:'' });
});

router.get('/fetch', (request, response, next) => {
  axios.get('http://localhost:8081/contacts')
       .then(resp => {
          console.log(resp.data);
          response.render('index', { title: 'Making a call to a rest service with Promise to get Data', data: JSON.stringify(resp.data) });
       })
       .catch((err) => {
          // The 'catch' method is executed only when the request fails to complete.
          console.log(err);
          response.render('index', { title: 'ERROR!' + ' Check whether simple service is running on port 8081', data: err });
       });

});

router.get('/add', (request, response, next) => {
  doPostRequest().then((result) => {
    response.render('index', { title: 'Making a call to a rest service with Promise to add Data', data: JSON.stringify(result) });
  });
  
});

async function doPostRequest() {

  let bodyData = 		{
    "firstname": "Abigale",
    "lastname": "Johnson",
    "title": "Mrs.",
    "company": "Fidelity",
    "jobtitle": "CEO",
    "primarycontactnumber": "+15551231234",
    "othercontactnumbers": [],
    "primaryemailaddress": "Abigale.Johnson@fidelity.com",
    "emailaddresses": [
      "CEO@fidelity.com"
    ],
    "groups": [
      "Executives"
    ]
  };

  let res;
  try {
    res = await axios.post('http://localhost:8081/add', bodyData);
  } catch (error) {
    console.log('Caught error posting data');
    return 'something went wrong!: ' + error;
  }
  let data = res.data;
  return data;
}


module.exports = router;
